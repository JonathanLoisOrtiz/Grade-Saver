# Student App Ideas

# purpose of the program
print("")
print("This app will help you know what percent you need on your next exam(s) to get an A on a class!")
print("")

# input how many tests the user will take
numberOfTests = int(input("How many tests will take this semester? "))

if numberOfTests < 0:
  print("You cannot have negative tests")
  numberOfTests = int(input("How many tests will take this semester? "))

# if the user says they have 0 tests the program stops
if numberOfTests == 0:
  print("Lucky you, you don't have tests for this semester!")
else:
  testsTaken = int(input("How many tests have you already taken this semester? "))
  
# prevents user from typing they've take more tests than theyre supposed to have
while testsTaken > numberOfTests:
  print("Thats not possible")
  testsTaken = int(input("How many tests have you already taken this semester? "))
  
  # user took all his tests
  if testsTaken == numberOfTests:
    print("You already took all your tests")

# variables for later use in program
testsLeft = numberOfTests - testsTaken
acumPoints = 0
GradesLst = []

# the program asks for percentages based on the amount of tests the user took
if numberOfTests > 0 and testsTaken != numberOfTests:
  
  for i in range (1 , testsTaken + 1 ):
    print ("What percentage did you get on test #", i ,"?")
    TestGrade = int(input())
    GradesLst.append(TestGrade)
    acumPoints += TestGrade

print("Your Grades this semester:" , GradesLst)

# displays the your current grade in the class
percent = (acumPoints / (testsTaken))
print("You currently have a", round(percent, 1) , "percent in your class") 
MaxPoints = (testsLeft * 100)

for n in range(1,MaxPoints + 1):
  if (acumPoints + n) / numberOfTests == 90 and n > 100:
    print("you need to get", n / testsLeft , "% on your next", testsLeft, "tests to get an A")
    
  elif (acumPoints + n) / numberOfTests == 90 and n <= 100:
    print("you need to get", n , "% on your next test to get an A")
  
if round((acumPoints + MaxPoints) / numberOfTests , 1) < 90:
    print("You won't be able to get an A with tests alone   but a perfect in next test would get you to a", round((acumPoints + 100*testsLeft) / numberOfTests , 1) , ("%"))























